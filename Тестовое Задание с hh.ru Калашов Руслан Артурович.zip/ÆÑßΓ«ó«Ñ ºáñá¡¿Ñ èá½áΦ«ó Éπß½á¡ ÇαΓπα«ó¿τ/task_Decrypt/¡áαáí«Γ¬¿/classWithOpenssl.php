<?php

// phpinfo();
// нужно прописать расширение в php.ini php_openssl.dll ( extension = php_openssl.dll )(строка в php.ini приблизительно 920)
// нужно в папке php/ext вашего сервера добавить файл php_openssl.dll

class coderAndDecoder{
	function __construct(){
		$this->tokenA = 'campid'; //текст который шифруется
		$this->tokenB = 'matchtype';


		$iv_size = 16; // 128 bits
		$iv = openssl_random_pseudo_bytes($iv_size, $strong);
		$key_size = 32; // 256 bits
		$encryption_key = openssl_random_pseudo_bytes($key_size, $strong);
		$this->iv = $iv;
		$this->encryption_key = $encryption_key;

 
		$txt = 'Тестируем обратимое шифрование на php';
		$encrypted = $this->encrypt($this->tokenA, $encryption_key);
		echo 'encrypt | '.$encrypted.'<br>';
		echo '<br>';
		echo '<br>';
		$decrypted = $this->decrypt($encrypted, $encryption_key);
		echo 'decrypt | '.$decrypted.'<br>';
		echo '<br>';
		echo '<br>';
	}

// ============================================================
// ВАРИАНТ 1
// ============================================================
	public function encrypt($decrypted, $key) {//шифратор

		function pkcs7_pad($data, $size)
		{
		    $length = $size - strlen($data) % $size;
		    return $data . str_repeat(chr($length), $length);
		};

		$enc_name = openssl_encrypt(
		    pkcs7_pad($decrypted, 16), // padded data
		    'AES-256-CBC',        // cipher and mode
		    $key,      // secret key
		    0,                    // options (not used)
		    $this->iv                   // initialisation vector
		);

		return $enc_name;
	}
	public function decrypt($encrypted, $key) {//дешифратор
		//НЕ РАБОТАЕТ??
		//не понимаю почему не работает
		function pkcs7_unpad($data)
		{
		    return substr($data, 0, -ord($data[strlen($data) - 1]));
		}

		$name = pkcs7_unpad(openssl_decrypt(
		    $encrypted,
		    'AES-256-CBC',
		    $key,
		    0,
		    $this->iv
		));
	}

}

$result = new coderAndDecoder();


print_r($result);

?>