<?php

// phpinfo();
// работает на php 5.2, (с 7.0 является устаревшим)
// нужно прописать расширение в php.ini php_mcrypt.dll ( extension = php_mcrypt.dll )(строка в php.ini приблизительно 920)
// нужно прописать расширение в php.ini php_curl.dll ( extension = php_curl.dll )(строка в php.ini приблизительно 920)
// нужно в папке php/ext вашего сервера добавить файл php_mcrypt.dll
// нужно в папке php/ext вашего сервера добавить файл php_curl.dll

class decryptSempai{
	function __construct(){
		//прошлый data
		// $this->data = 'SvKG241v7E4p8P7poyEEFwCwdBSvE0f8qxyXMbYRcuS5Jg5czH/J8/7EQEWlTejGEcGFjiMjBNH9YlOUiHzwohhIVx35HlIZpD5ZN1C4eLsnR3x3FccCyxZFKWlgR+DCfH8dcFC8xWLnFreYZ0deATytimlfd8S5WQUhPLECFx50x8OcOIHxcm+7/nN/XLorHz8SiLlgeLhzZiSGJPm3GjnfAOtqRaGVC1WgCZT93WA7tbVOl+owcat0NE+OfyiAAEbOlBlItYZliy0NH5AlMHORaQIf+exxP/lmb2OB6F1OEqp7/DO2QxIHAq/eHwo7zpqTfWgdJnjAPXqxv7VBg/FFZS22rNNf67lSGo4jXc0g==';

		// новый data
		// $this->data = "iTde7ULVD4u1I35rSijRVwGqV8SPd9uL1b7jxNrzl27olU4qu8mgIztLuZVzUnXPefs+YJrcjYzh4PxNrxeXJ8={gclid}&Qnpg/Saqq10jahTeocDCTQUym5/riUpG4OgXI6GXh1dsS0jYnQYskLjBqZsAUVC3qpbWh/qF2ZzWEWStyeUJG3={placement}&FDW6xaF3IGaoKQMLkFKKegYNVlmjMcHXyp3NJjMR9XAB6bGGP4BgL1SfTuB1UrzDYNd5AULG4OhcBafgsN3n8A={adposition}&/GhtRrQ8bKhFYEnuGNor4AYjclOovGF0pi0C5OQ/rv3p5z55ArD3jiEPduckyGu2LYvXz99vtcwtr0fQW38jAC={campaignid}&/hN3fWD4kCL6D+eKN1ujfgaiJrt46dxzjsChE6ubUNSyLKTcGd9hLvDHDxEi5YsOdByGXjHJXlqdk0ZHNucdSd={device}&GDbZbaOtjdTINd3e7tTzVASKTOVERv0ndAYEOc/4mTbXmPj7TEtjyPFQCkUFJIRDv12kPRrfYnwOitPaTQME9s={devicemodel}&SdCUFX5bYb6t1CzqPkUcYgnyDbZBCEm3KnXzlhjdXoN7/YPo4esB2YMPD9lXYp1A+TF4BYRri995yIhOVwbWDI={creative}&kuOmdfEADt+r6tKuJa4dqAmVgBzYEK9KIPi6h33AMCbf14/lyc/BSVbXe4Rnv1GFGDWXhMtdCshJowqG6QL9CV={adid}&824Rjf2ckjrAetAqpA/0JgFW9GLwdcDW8K4TxK8ngk2Np6Dbd83JH+UXL/9yXnMHFyBUjScVuHVFfg7LjfEFfo={targetid}&bXHTXaAx7svtgSdevGil2wauW/wFX8iYCDf62vJeTNUZ9IZA3TW9+y+JnJbu9dwodzCToHodX3YiBVn7rOygwJ={keyword}&/uzt5Ny+I5UzANVKa7guyQ5h9COUgbwYVYbXZgoNO4G+WZeCwjmYPP7vx/eVv9oKuUtmCEbjCx++cl3iKknOQY={matchtype}";

		$this->data = $this->getDataPost_withCurl();

		//внутреннее шифрование строки
		define('ENCRYPTION_KEY_INSIDE', '_91X:s+{a2Jwb6*J');//ключ шифрования в константе
		define('ENCRYPTION_METHOD_INSIDE', MCRYPT_RIJNDAEL_128);//тип шифрования
		define('HASH_TYPE_INSIDE', 'sha256');//тип хэша


		// поиск ключей по регулярке
		$keysArr = array();
		preg_match_all(
			"/[a-zA-Z0-9\+\/]{1,}=/", //регулярка
		    $this->data,
		    $keysArr
		);
		$keysArr = $keysArr[0];

		// делаем массив значений
		$keysArr_values = array();
		preg_match_all(
			"/{[a-zA-Z0-9\+\/]{1,}}/", //регулярка
		    $this->data,
		    $keysArr_values
		);
		$keysArr_values = $keysArr_values[0];
		// print_r($keysArr_values);
		// echo '<br>';
		// echo '<br>';


		// соединяем в правильную строку запроса с данными
		$newKeysArr = array();
		foreach($keysArr as $key => $value){
			$encrypted = $this->decrypt($value, ENCRYPTION_KEY_INSIDE, ENCRYPTION_METHOD_INSIDE, HASH_TYPE_INSIDE);
			array_push($newKeysArr, $encrypted);
		};
		// print_r($newKeysArr);
		$this->DecryptData = ''; //готовим новую строку с шифрами ключей
		foreach ($newKeysArr as $key2 => $value2) {
			$nameKey = preg_replace("/=/", '', $value2);
			$this->DecryptData .= $nameKey.'={'.preg_replace('/[\{\}]/', '', $keysArr_values[$key2]).'}&';
		};
		$this->DecryptData = trim(substr($this->DecryptData, 0, strlen($this->DecryptData)-1 )); //обрезаем лишний символ

		// все готово отправляем
		$url = parse_url($_SERVER['REQUEST_URI']);
		echo 'http://'.$_SERVER['HTTP_HOST'].$url['path'].'?'.$this->DecryptData;



		// echo '<br>';
		// echo '<br>';
		// echo strlen($this->DecryptData).' | '.strlen('gclid={gclid}&placement={placement}&adposition={adposition}&campid={campaignid}&device={device}&devicemodel={devicemodel}&creative={creative}&adid={adid}&target={targetid}&keyword={keyword}&matchtype={matchtype}');
		// echo '<br>';
		// echo '<br>';
		// echo 'test | '.(strlen($this->DecryptData) == strlen('gclid={gclid}&placement={placement}&adposition={adposition}&campid={campaignid}&device={device}&devicemodel={devicemodel}&creative={creative}&adid={adid}&target={targetid}&keyword={keyword}&matchtype={matchtype}'));
		// echo 'hello world';
		// echo '<br>';
		// echo '<br>'; 
 		
 		// вариант 2 - шифрование всей части строки запроса (той части что идет после знака ?, с данными) 
		// $txt = 'Тестируем обратимое внутреннее шифрование на php';
		// $decrypted = $this->decrypt($this->data, ENCRYPTION_KEY_INSIDE, ENCRYPTION_METHOD_INSIDE, HASH_TYPE_INSIDE);
		// echo "<p style='width:1000px; word-break:break-all;'>"."расшифровываем данные | ".$decrypted."<br>"."</p>";
		// echo '<br>';
		// echo '<br>';	
	}


// ============================================================
// ВАРИАНТ 2
// ============================================================
	public function decrypt($encrypted, $key, $method, $hashMethod) {//дешифратор
		$ekey = hash($hashMethod, $key, true);
		$iv = base64_decode(substr($encrypted, 0, 22) . '==');
		$encrypted = substr($encrypted, 22);
		$decrypted = rtrim(mcrypt_decrypt($method, $ekey, base64_decode($encrypted), MCRYPT_MODE_CBC, $iv), "\0\4");
		$hash = substr($decrypted, -32);
		$decrypted = substr($decrypted, 0, -32);

		if (md5($decrypted) != $hash) return false; //сравниваем хэш
		return $decrypted;
	}


	public function getDataPost_withCurl()
	{	
		$url = parse_url($_SERVER['REQUEST_URI']);
		return htmlspecialchars($url['query']);
	}

}

$result = new decryptSempai();
?>