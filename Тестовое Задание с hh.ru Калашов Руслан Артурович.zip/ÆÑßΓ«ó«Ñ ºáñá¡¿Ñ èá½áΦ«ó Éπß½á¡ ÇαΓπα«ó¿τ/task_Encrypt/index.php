<?php

// phpinfo();
// работает на php 5.2, (с 7.0 является устаревшим)
// нужно прописать расширение в php.ini php_mcrypt.dll ( extension = php_mcrypt.dll )(строка в php.ini приблизительно 920)
// нужно прописать расширение в php.ini php_curl.dll ( extension = php_curl.dll )(строка в php.ini приблизительно 920)
// нужно в папке php/ext вашего сервера добавить файл php_mcrypt.dll
// нужно в папке php/ext вашего сервера добавить файл php_curl.dll

class encryptSempai{
	function __construct($adress){
		$dataArr = parse_url($adress);
		$this->data = $dataArr['query'];


		//внутреннее шифрование строки
		define('ENCRYPTION_KEY_INSIDE', '_91X:s+{a2Jwb6*J');//ключ шифрования в константе
		define('ENCRYPTION_METHOD_INSIDE', MCRYPT_RIJNDAEL_128);//тип шифрования
		define('HASH_TYPE_INSIDE', 'sha256');//тип хэша

		// поиск ключей по регулярке
		$keysArr = array();
		preg_match_all(
			"/[a-zA-Z0-9\+\/]{1,}=/", //регулярка
		    $this->data,
		    $keysArr
		);
		$keysArr = $keysArr[0];

		// делаем массив значений
		$keysArr_values = array();
		preg_match_all(
			"/{[a-zA-Z0-9\+\/]{1,}}/", //регулярка
		    $this->data,
		    $keysArr_values
		);
		$keysArr_values = $keysArr_values[0];
		print_r($keysArr_values);
		echo '<br>';
		echo '<br>';

		// соединяем в правильную строку запроса с данными
		$newKeysArr = array();
		foreach($keysArr as $key => $value){
			$encrypted = $this->encrypt($value, ENCRYPTION_KEY_INSIDE, ENCRYPTION_METHOD_INSIDE, HASH_TYPE_INSIDE);
			array_push($newKeysArr, $encrypted);
		};
		$this->CryptData = ''; //готовим новую строку с шифрами ключей
		foreach ($newKeysArr as $key2 => $value2) {
			$nameKey = preg_replace("/=/", '', $keysArr[$key2]);
			$this->CryptData .= $value2.'={'.preg_replace('/[\{\}]/', '', $keysArr_values[$key2]).'}&';
		};
		$this->CryptData = substr($this->CryptData, 0, strlen($this->CryptData)-1 ); //обрезаем лишний символ


		echo $this->CryptData;
		echo '<br>';
		echo '<br>'; 

		$this->sendDataPost_withCurl('http://'.$_SERVER['HTTP_HOST'].$dataArr['path'], $this->CryptData);
 		// вариант 2 - шифрование всей части строки запроса (той части что идет после знака ?, с данными) 
		// $txt = 'Тестируем обратимое внутреннее шифрование на php';
		// $encrypted = $this->encrypt($this->data, ENCRYPTION_KEY_INSIDE, ENCRYPTION_METHOD_INSIDE, HASH_TYPE_INSIDE);
		// echo "<p style='width:1000px; word-break:break-all;'>"."шифруем данные | ".$encrypted."<br>"."</p>";
		// echo '<br>';
		// echo '<br>';
	}


// ============================================================
// ВАРИАНТ 2
// ============================================================
	public function encrypt($decrypted, $key, $method, $hashMethod) {//шифратор
		$ekey = hash($hashMethod, $key, true);
		// srand(); 
		$iv = mcrypt_create_iv(mcrypt_get_iv_size($method, MCRYPT_MODE_CBC), MCRYPT_RAND);
		
		if (strlen($iv_base64 = rtrim(base64_encode($iv), '=')) != 22) return false;
		$encrypted = base64_encode(mcrypt_encrypt($method, $ekey, $decrypted . md5($decrypted), MCRYPT_MODE_CBC, $iv));

		return $iv_base64 . $encrypted;
	}

	public function sendDataPost_withCurl($adress, $data_string)
	{
		$curl = curl_init($adress.'?'.$data_string);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_HEADER, false);
		$result = curl_exec($curl);
		curl_close($curl);

		echo '<br>';
		echo '<br>'; 
		echo '_____________________________________________'; 
		echo '<br>'; 
		echo 'test:'; 
		echo '<br>'; 
		echo $result;
	}

}

$result = new encryptSempai('http://localhost/task_Decrypt?gclid={gclid}&placement={placement}&adposition={adposition}&campid={campaignid}&device={device}&devicemodel={devicemodel}&creative={creative}&adid={adid}&target={targetid}&keyword={keyword}&matchtype={matchtype}');


// print_r($result);
?>